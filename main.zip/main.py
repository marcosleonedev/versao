import AutoUpdate

AutoUpdate.set_url("https://github.com/marcosleonedev/versao/blob/main/versao.txt")
AutoUpdate.set_current_version("1.0.0")
print(AutoUpdate.is_up_to_date())

if not AutoUpdate.is_up_to_date():
    AutoUpdate.download("https://github.com/marcosleonedev/versao/blob/main/versao.txt")